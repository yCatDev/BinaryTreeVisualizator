﻿namespace Nez.AI.BehaviorTrees
{
	public enum TaskStatus
	{
		Invalid,
		Success,
		Failure,
		Running
	}
}